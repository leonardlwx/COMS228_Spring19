package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;

import org.junit.Before;
import org.junit.Test;

public class WildlifeTest {
	/**
	 * Plain for test case
	 */
	private Plain test;
	private Plain test1;
	
	/**
	 * Setup world 3x3 grid
	 * @throws FileNotFoundException 
	 */
	@Before
	public void setup() throws FileNotFoundException {
		test = new Plain("public3-10x10.txt");
		test1 = new Plain("public3-6cycles.txt");
	}
	
	/**
	 * Test for proper updating of a world
	 * @throws FileNotFoundException
	 */
	@Test
	public void testUpdatePlain() {
		String str = test1.toString();
		Plain p = new Plain(test.getWidth());
		
		int i;
		for(i = 0; i < 6; i++) {
			if(i % 2 == 0) {
				Wildlife.updatePlain(test, p);
			} 
			else {
				Wildlife.updatePlain(p, test);
			}
		}
		
		assertEquals(p.toString(), str);
	}
}
