package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;

import org.junit.Before;
import org.junit.Test;

/**
 * 
 * @author Wei Xian Lim
 *
 */

public class LivingTest {
	/**
	 * Internal Plain
	 */
	private Plain test;
	
	/**
	 * Setup method
	 * @throws FileNotFoundException 
	 */
	@Before
	public void setup() throws FileNotFoundException {
		test = new Plain("public1-3x3.txt");
	}
	
	/**
	 * Check if census works as intended
	 */
	@Test
	public void testCensus() {
		int set[] = new int[Living.NUM_LIFE_FORMS];
		test.grid[1][1].census(set);
		assertEquals(set[Living.BADGER], 1);
		assertEquals(set[Living.FOX], 4);
		assertEquals(set[Living.GRASS], 2);
		assertEquals(set[Living.RABBIT], 1);
		assertEquals(set[Living.EMPTY], 1);
		
		int set2[] = new int[Living.NUM_LIFE_FORMS];
		test.grid[2][2].census(set2);
		assertEquals(set2[Living.FOX], 1);
		assertEquals(set2[Living.GRASS], 1);
		assertEquals(set2[Living.RABBIT], 1);
		assertEquals(set2[Living.EMPTY], 1);
	}
}
