package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * 
 * @author Wei Xian Lim
 *
 */

public class EmptyTest {
	/**
	 * Plain for test case
	 */
	private Plain test;
	
	/**
	 * Living type to keep
	 */
	private Empty e;
	
	/**
	 * Setup Plain 3x3 grid
	 */
	@Before
	public void setup() {
		test = new Plain(3);
		e = new Empty(test, 0, 0);
		//make a neighborhood
		test.grid[0][0] = e;
		test.grid[0][1] = new Grass(test, 0, 1);
		test.grid[1][0] = new Grass(test, 1, 0);
	}
	
	/**
	 * Test .who() method
	 */
	@Test
	public void testState() {
		assertEquals(State.EMPTY, e.who());
	}
	
	/**
	 * Test .next() method
	 */
	@Test
	public void testNext() {
		Plain test2 = new Plain(3);
		Living n = e.next(test2);
		assertEquals(State.GRASS, n.who());
	}
}
