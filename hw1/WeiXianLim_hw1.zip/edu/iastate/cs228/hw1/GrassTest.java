package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class GrassTest {
	/**
	 * Plain for test case
	 */
	private Plain test;
	
	/**
	 * Grass element
	 */
	private Grass g;
	
	/**
	 * Setup Plain 3x3 grid
	 */
	@Before
	public void setup() {
		test = new Plain(3);
		g = new Grass(test, 0, 0);
		test.grid[0][0] = g;
		test.grid[1][0] = new Rabbit(test, 1, 0, 0);
		test.grid[0][1] = new Rabbit(test, 0, 1, 0);
		test.grid[1][1] = new Rabbit(test, 1, 1, 0);
	}
	
	/**
	 * Test .who() method
	 */
	@Test
	public void testState() {
		Grass g = new Grass(test, 0, 0);
		assertEquals(State.GRASS, g.who());
	}
	
	/**
	 * Test .next() method
	 */
	@Test
	public void testNext() {
		Plain test2 = new Plain(3);
		Living n = g.next(test2);
		//System.out.println(n.toString());
		assertEquals(State.EMPTY, n.who());
	}
}
