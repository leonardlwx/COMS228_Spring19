package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class RabbitTest {
	/**
	 * Plain for test case
	 */
	private Plain test;
	
	/**
	 * Rabbit element
	 */
	private Rabbit r;
	
	/**
	 * Setup world 3x3 grid
	 */
	@Before
	public void setup() {
		test = new Plain(3);
		r = new Rabbit(test, 0, 0, 0);
		test.grid[0][0] = r;
	}
	
	/**
	 * Test .who() method
	 */
	@Test
	public void testState() {
		assertEquals(State.RABBIT, r.who());
	}
	
	/**
	 * Test .next() method
	 */
	@Test
	public void testNext() {
		Plain test = new Plain(3);
		Living n = r.next(test);
		//System.out.println(n.toString());
		assertEquals(State.EMPTY, n.who());
	}
}
