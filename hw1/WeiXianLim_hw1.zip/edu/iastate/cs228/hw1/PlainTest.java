package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;

import org.junit.Before;
import org.junit.Test;

public class PlainTest {
	/**
	 * Plain for test case
	 */
	private Plain test;
	
	/**
	 * Setup Plain 3x3 grid
	 */
	@Before
	public void setup() {
		test = new Plain(3);
		test.randomInit();
	}
	
	/**
	 * Test for proper writing and reading of file
	 * @throws FileNotFoundException
	 */
	@Test
	public void testReadfile() throws FileNotFoundException {
		String str = "testing123";
		test.write(str);
		Plain test2 = new Plain(str);
		assertEquals(test2.toString(), test.toString());
	}
	
	@Test
	public void testWidth() {
		assertEquals(test.getWidth(), 3);
	}
}
