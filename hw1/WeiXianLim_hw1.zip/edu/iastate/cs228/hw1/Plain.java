package edu.iastate.cs228.hw1;

/**
 *  
 * @author
 *
 */

import java.io.File; 
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner; 
import java.util.Random; 

/**
 * 
 * The plain is represented as a square grid of size width x width. 
 *
 */
public class Plain 
{
	private int width; // grid size: width X width 
	
	public Living[][] grid; 
	
	/**
	 *  Default constructor reads from a file 
	 */
	public Plain(String inputFileName) throws FileNotFoundException
	{		
		// 
		// Assumption: The input file is in correct format. 
		// 
		// You may create the grid plain in the following steps: 
		// 
		// 1) Reads the first line to determine the width of the grid.
		// 
		// 2) Creates a grid object. 
		// 
		// 3) Fills in the grid according to the input file. 
		// 
		// Be sure to close the input file when you are done. 
		File file = new File(inputFileName);
		Scanner scan = new Scanner(file);
		int w = -1;
		int i = 0, j = 0;
		while(scan.hasNextLine()) {
			String s = scan.nextLine();
			if(w < 0) {
				w = s.length() / 3;
				grid = new Living[w][w];
				width = w;
			}
			
			s.replace("  ", " ");
			s.replace('\n', ' ');
			s.trim();
			Scanner sc = new Scanner(s);
			sc.useDelimiter(" ");
			for(j = 0; sc.hasNext(); j++) {
				String ch = sc.next();
				ch.trim();
				ch.replace(" ", "");
				
				if(ch.length() > 0) {
					char c = ch.charAt(0);
					if(ch.length() == 1) {
						if(c == 'E') {
							grid[i][j] = new Empty(this, i, j);
						} 
						else if(c == 'G') {
							grid[i][j] = new Grass(this, i, j);
						}
					} 
					else if(ch.length() == 2) {
						int d = Character.getNumericValue(ch.charAt(1));
						if(c == 'B') {
							grid[i][j] = new Badger(this, i, j, d);
						}
						else if(c == 'F') {
							grid[i][j] = new Fox(this, i, j, d);
						}
						else if(c == 'R') {
							grid[i][j] = new Rabbit(this, i, j, d);
						}
					}
				} 
				else {
					j--;
					continue;
				}
			}
			i++;
			sc.close();
		}
		scan.close();
	}
	
	/**
	 * Constructor that builds a w x w grid without initializing it. 
	 * @param width  the grid 
	 */
	public Plain(int w){
		grid = new Living[w][w];
		width = w;
	}
	
	
	public int getWidth(){
		return width;  // to be modified 
	}
	
	/**
	 * Initialize the plain by randomly assigning to every square of the grid  
	 * one of BADGER, FOX, RABBIT, GRASS, or EMPTY.  
	 * 
	 * Every animal starts at age 0.
	 */
	public void randomInit(){
		Random random = new Random(); 
		 int i, j;
		 for(i = 0; i < grid.length; i ++) {
			 for(j = 0; j < grid.length; j ++) {
				 int num = random.nextInt(Living.NUM_LIFE_FORMS);
				 if(num == Living.BADGER) {
					 grid[i][j] = new Badger(this, i, j, 0);
				 }
				 else if (num == Living.EMPTY) {
					 grid[i][j] = new Empty(this,i,j);
				 }
				 else if (num == Living.FOX) {
					 grid[i][j] = new Fox(this, i, j, 0);
				 }
				 else if (num == Living.RABBIT) {
					 grid[i][j] = new Rabbit(this, i, j, 0);
				 }
				 else if (num == Living.GRASS) {
					 grid[i][j] = new Grass(this,i,j);
				 }
			 }
		 }
	}
	
	
	/**
	 * Output the plain grid. For each square, output the first letter of the living form
	 * occupying the square. If the living form is an animal, then output the age of the animal 
	 * followed by a blank space; otherwise, output two blanks.  
	 */
	public String toString()
	{
		int i, j;
		String result = "";
		for(i = 0; i < grid.length; i ++) {
			 for(j = 0; j < grid.length; j ++) {
				 State st = grid[i][j].who();
				 boolean isAnimal = false;
				 String toAdd = null;
				 if(st == State.BADGER) {
					 isAnimal = true;
					 toAdd = "B";
				 }
				 else if(st == State.EMPTY) {
					 isAnimal = false;
					 toAdd = "E";
				 }
				 else if(st == State.GRASS) {
					 isAnimal = false;
					 toAdd = "G";
				 }
				 else if(st == State.FOX) {
					 isAnimal = true;
					 toAdd = "F";
				 }
				 else if(st == State.RABBIT) {
					 isAnimal = true;
					 toAdd = "R";
				 } 
				 else {
					 isAnimal = false;
					 toAdd = "X";
				 }
				 if (isAnimal) {
					 result += toAdd + ((Animal)grid[i][j]).myAge() + " ";
				 }
				 else {
					 result += toAdd + "  ";
				 }
			 }
			 result += "\n"; //new line
		}
		return result; 
	}
	

	/**
	 * Write the plain grid to an output file.  Also useful for saving a randomly 
	 * generated plain for debugging purpose. 
	 * @throws FileNotFoundException
	 */
	public void write(String outputFileName) throws FileNotFoundException
	{
		// 
		// 1. Open the file. 
		// 
		// 2. Write to the file. The five life forms are represented by characters 
		//    B, E, F, G, R. Leave one blank space in between. Examples are given in
		//    the project description. 
		// 
		// 3. Close the file. 
		File file = new File(outputFileName);
		PrintWriter pw = new PrintWriter(file);
		String s = this.toString();
		pw.write(s);
		pw.close();
	}			
}
