package edu.iastate.cs228.hw1;

/**
 *  
 * @author Wei Xian Lim
 *
 */

/*
 * A rabbit eats grass and lives no more than three years.
 */
public class Rabbit extends Animal {	
	/**
	 * Creates a Rabbit object.
	 * @param p: plain  
	 * @param r: row position 
	 * @param c: column position
	 * @param a: age 
	 */
	public Rabbit (Plain p, int r, int c, int a) {
		plain = p;
		row = r;
		column = c;
		age = a;
	}
		
	// Rabbit occupies the square.
	public State who(){
		return State.RABBIT; 
	}
	
	/**
	 * A rabbit dies of old age or hunger. It may also be eaten by a badger or a fox.  
	 * @param pNew     plain of the next cycle 
	 * @return Living  new life form occupying the same square
	 */
	public Living next(Plain pNew){
		int life[] = new int[Living.NUM_LIFE_FORMS];
		this.census(life);
		
		if (this.age >= Living.RABBIT_MAX_AGE) {
			return new Empty(pNew, this.row, this.column);	
		}
		else if (life[Living.GRASS] < 1) {
			return new Empty(pNew, this.row, this.column);
		}
		else if (life[Living.BADGER] + life[Living.FOX] >= life[Living.RABBIT] && life[Living.FOX] >= life[Living.BADGER]) {
			return new Fox(pNew, this.row, this.column, 0);
		}
		else if (life[Living.BADGER] > life[Living.RABBIT]) {
			return new Badger(pNew, this.row, this.column, 0);
		}
		else {
			this.age ++;
			this.plain = pNew;
			return this;
		}
	}
}
