package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * 
 * @author Wei Xian Lim
 *
 */

public class FoxTest {
	/**
	 * Plain for test case
	 */
	private Plain test;
	
	/**
	 * Rabbit element
	 */
	private Fox f;
	
	/**
	 * Setup plain 3x3 grid
	 */
	@Before
	public void setup() {
		test = new Plain(3);
		f = new Fox(test, 0, 0, 0);
		test.grid[0][0] = f;
		test.grid[0][1] = new Badger(test, 0, 1, 0);
		test.grid[1][1] = new Badger(test, 1, 1, 0);
	}
	
	/**
	 * Test .who() method
	 */
	@Test
	public void testState() {
		Fox e = new Fox(test, 0, 0, 0);
		assertEquals(State.FOX, e.who());
	}
	
	/**
	 * Test .next() method
	 */
	@Test
	public void testNext() {
		Plain test2 = new Plain(3);
		Living n = f.next(test2);
		//System.out.println(n.toString());
		assertEquals(State.BADGER, n.who());
	}
}
