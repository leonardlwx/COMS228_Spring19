package edu.iastate.cs228.hw1;

import java.io.FileNotFoundException;

import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.assertEquals;

/**
 * 
 * @author Wei Xian Lim
 *
 */

public class AnimalTest {
	private Plain p;
	
	@Before
	public void setup() throws FileNotFoundException {
		p = new Plain ("public1-3x3.txt");
	}
	
	@Test
	public void testAge() {
		assertEquals(((Animal)p.grid[1][1]).myAge(), 0);
	}
}
