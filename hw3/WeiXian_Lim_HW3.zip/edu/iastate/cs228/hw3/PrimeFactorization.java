package edu.iastate.cs228.hw3;

/**
 *  
 * @author Wei Xian Lim
 *
 */

import java.util.ListIterator;


public class PrimeFactorization implements Iterable<PrimeFactor>
{
	private static final long OVERFLOW = -1;
	private long value; 	// the factored integer 
	// it is set to OVERFLOW when the number is greater than 2^63-1, the
	// largest number representable by the type long. 

	/**
	 * Reference to dummy node at the head.
	 */
	private Node head;

	/**
	 * Reference to dummy node at the tail.
	 */
	private Node tail;

	private int size;     	// number of distinct prime factors


	// ------------
	// Constructors 
	// ------------

	/**
	 *  Default constructor constructs an empty list to represent the number 1.
	 *  
	 *  Combined with the add() method, it can be used to create a prime factorization.  
	 */
	public PrimeFactorization() {	 
		value = 1;
		head = new Node();
		tail = new Node();
		size = 0;
		head.next = tail;
		tail.previous = head;
	}


	/** 
	 * Obtains the prime factorization of n and creates a doubly linked list to store the result.   
	 * Follows the direct search factorization algorithm in Section 1.2 of the project description. 
	 * 
	 * @param n
	 * @throws IllegalArgumentException if n < 1
	 */
	public PrimeFactorization(long n) throws IllegalArgumentException {
		if (n < 1) {
			throw new IllegalArgumentException();
		}
		value = n;
		head = new Node();
		tail = new Node();
		size = 0;
		head.next = tail;
		tail.previous = head;
		for (int i = 2; i <= Math.sqrt(n) ; i ++) {
			int multiplicity = 0;
			while(n % i == 0) {
				multiplicity ++;
				n = n / i;
			}
			if (multiplicity != 0){
				this.add(i, multiplicity);
			}
		}
		if (n > 2)
			add((int) n, 1);
	}


	/**
	 * Copy constructor. It is unnecessary to verify the primality of the numbers in the list.
	 * 
	 * @param pf
	 */
	public PrimeFactorization(PrimeFactorization pf){
		this.value = pf.value();
		this.head = new Node();
		this.tail = new Node();
		this.size = pf.size;
		head.next = tail;
		tail.previous = head;
		PrimeFactorizationIterator p = pf.iterator();
		while(p.hasNext()){
			PrimeFactor f = p.next();
			this.add(f.prime, f.multiplicity);
		}
	}

	/**
	 * Constructs a factorization from an array of prime factors.  Useful when the number is 
	 * too large to be represented even as a long integer. 
	 * 
	 * @param pflist
	 */
	public PrimeFactorization (PrimeFactor[] pfList){
		this.head = new Node();
		this.tail = new Node();
		size = pfList.length;
		head.next = tail;
		tail.previous = head;
		for (int i = 0; i < size; i ++) {
			add(pfList[i].prime, pfList[i].multiplicity);
		}
		updateValue();
	}



	// --------------
	// Primality Test
	// --------------

	/**
	 * Test if a number is a prime or not.  Check iteratively from 2 to the largest 
	 * integer not exceeding the square root of n to see if it divides n. 
	 * 
	 *@param n
	 *@return true if n is a prime 
	 * 		  false otherwise 
	 */
	public static boolean isPrime(long n) {
		for (long i = 2; i < Math.sqrt(n); i++) {
			if (n % i == 0) {
				return false;
			}
		}
		return true;
	}   


	// ---------------------------
	// Multiplication and Division 
	// ---------------------------

	/**
	 * Multiplies the integer v represented by this object with another number n.  Note that v may 
	 * be too large (in which case this.value == OVERFLOW). You can do this in one loop: Factor n and 
	 * traverse the doubly linked list simultaneously. For details refer to Section 3.1 in the 
	 * project description. Store the prime factorization of the product. Update value and size. 
	 * 
	 * @param n
	 * @throws IllegalArgumentException if n < 1
	 */
	public void multiply(long n) throws IllegalArgumentException {
		if (n < 1) {
			throw new IllegalArgumentException();
		}
		else {
			PrimeFactorization temp = new PrimeFactorization(n);
			multiply(temp);
		}
		updateValue();
	}

	/**
	 * Multiplies the represented integer v with another number in the factorization form.  Traverse both 
	 * linked lists and store the result in this list object.  See Section 3.1 in the project description 
	 * for details of algorithm. 
	 * 
	 * @param pf 
	 */
	public void multiply(PrimeFactorization pf){
		PrimeFactorizationIterator iter1 = this.iterator();
		PrimeFactorizationIterator iter2 = pf.iterator();
		PrimeFactor f1 = iter1.next();
		PrimeFactor f2 = iter2.next();
		while (iter1.hasNext() && iter2.hasNext()) {
			while(iter1.hasNext()) {
				if (f1.prime < f2.prime) {
					f1 = iter1.next();
				}
			}
			if (iter1.hasNext()) {
				if (f1.prime == f2.prime) {
					f1.multiplicity += f2.multiplicity;
				}

				else if (f1.prime > f2.prime) {
					iter1.add(f2);
				}
				f2 = iter2.next();
			}
		}
		if(iter2.hasNext()) {
			while (iter2.hasNext()) {
				iter1.add(f2);
				f2 = iter2.next();
			}
		}
		updateValue();
	}


	/**
	 * Multiplies the integers represented by two PrimeFactorization objects.  
	 * 
	 * @param pf1
	 * @param pf2
	 * @return object of PrimeFactorization to represent the product 
	 */
	public static PrimeFactorization multiply(PrimeFactorization pf1, PrimeFactorization pf2) {
		pf1.multiply(pf2);
		PrimeFactorization result = new PrimeFactorization(pf1);
		return result;
	}
		


	/**
	 * Divides the represented integer v by n.  Make updates to the list, value, size if divisible.  
	 * No update otherwise. Refer to Section 3.2 in the project description for details. 
	 *  
	 * @param n
	 * @return  true if divisible 
	 *          false if not divisible 
	 * @throws IllegalArgumentException if n <= 0
	 */
	public boolean dividedBy(long n) throws IllegalArgumentException {
		if (n <= 0) {
			throw new IllegalArgumentException();
		}
		if (value != -1 && value < n){
			return false;
		}
		PrimeFactorization temp = new PrimeFactorization(n);		
		return dividedBy(temp);
	}


	/**
	 * Division where the divisor is represented in the factorization form.  Update the linked 
	 * list of this object accordingly by removing those nodes housing prime factors that disappear  
	 * after the division.  No update if this number is not divisible by pf. Algorithm details are 
	 * given in Section 3.2. 
	 * 
	 * @param pf
	 * @return	true if divisible by pf
	 * 			false otherwise
	 */
	public boolean dividedBy(PrimeFactorization pf) {  // not finalize 
		if ((this.value != -1 && pf.value != -1 && this.value < pf.value) 
				|| (this.value != -1 && pf.value == -1)) {
			return false;
		}

		if (this.value == pf.value) {
			this.clearList();
			return true;
		}

		PrimeFactorizationIterator iter1 = this.iterator();
		PrimeFactorizationIterator iter2 = pf.iterator();
		PrimeFactor f1 = iter1.next();
		PrimeFactor f2 = iter2.next();
		

		while (iter2.cursor != pf.tail) {
			while (f1.prime < f2.prime) {
				if (!iter1.hasNext() && iter2.hasNext()) {
					return false;
				}

				else {
					f1 = iter1.next();
				}
			}
			if ((f1.prime > f2.prime) || (f1.prime == f2.prime && f1.multiplicity < f2.multiplicity)) {
				return false;
			}

			else {
				if (f1.multiplicity - f2.multiplicity != 0) {
					f1.multiplicity -= f2.multiplicity;
					f1 = iter1.next();
					f2 = iter2.next();
				}

				else {
					iter1.next();
					iter1.remove();
					f2 = iter2.next();
				}

			}
		}
		this.updateValue();
		return true;

	}


	/**
	 * Divide the integer represented by the object pf1 by that represented by the object pf2. 
	 * Return a new object representing the quotient if divisible. Do not make changes to pf1 and 
	 * pf2. No update if the first number is not divisible by the second one. 
	 *  
	 * @param pf1
	 * @param pf2
	 * @return quotient as a new PrimeFactorization object if divisible
	 *         null otherwise 
	 */
	public static PrimeFactorization dividedBy(PrimeFactorization pf1, PrimeFactorization pf2) { // Not gonna work
		pf1.dividedBy(pf2);
		PrimeFactorization result = new PrimeFactorization(pf1);
		return result;
	}


	// -------------------------------------------------
	// Greatest Common Divisor and Least Common Multiple 
	// -------------------------------------------------

	/**
	 * Computes the greatest common divisor (gcd) of the represented integer v and an input integer n.
	 * Returns the result as a PrimeFactor object.  Calls the method Euclidean() if 
	 * this.value != OVERFLOW.
	 *     
	 * It is more efficient to factorize the gcd than n, which can be much greater. 
	 *     
	 * @param n
	 * @return prime factorization of gcd
	 * @throws IllegalArgumentException if n < 1
	 */
	public PrimeFactorization gcd(long n) throws IllegalArgumentException {
		PrimeFactorization temp = null;
		if (n < 1) {
			throw new IllegalArgumentException();
		}
		if (value != OVERFLOW){
			long gcd = Euclidean(value, n);
			temp = new PrimeFactorization(gcd);
		}
		else {
			return this.gcd(new PrimeFactorization(n));
		}
		return temp;
	}


	/**
	 * Implements the Euclidean algorithm to compute the gcd of two natural numbers m and n. 
	 * The algorithm is described in Section 4.1 of the project description. 
	 * 
	 * @param m
	 * @param n
	 * @return gcd of m and n. 
	 * @throws IllegalArgumentException if m < 1 or n < 1
	 */
	public static long Euclidean(long m, long n) throws IllegalArgumentException {
		if (m < 1 || n < 1){
			throw new IllegalArgumentException();
		}
		long result = m;
		while (m % n != 0) {
			result = (m % n);
			m = n;
			n = result;
		}
		return result;
	}


	/**
	 * Computes the gcd of the values represented by this object and pf by traversing the two lists.  No 
	 * direct computation involving value and pf.value. Refer to Section 4.2 in the project description 
	 * on how to proceed.  
	 * 
	 * @param  pf
	 * @return prime factorization of the gcd
	 * @throws IllegalArguemntException if pf == null
	 */
	public PrimeFactorization gcd(PrimeFactorization pf) throws IllegalArgumentException {
		if (pf == null) {
			throw new IllegalArgumentException();
		}
		PrimeFactorizationIterator iter1 = this.iterator();
		PrimeFactorizationIterator iter2 = pf.iterator();
		PrimeFactorization result = new PrimeFactorization();

		while(iter2.hasNext()){
			PrimeFactor f1 = iter1.next();
			PrimeFactor f2 = iter2.next();
			while (f1.prime != f2.prime && iter1.hasNext()) {
				f1 = iter1.next();
			}
			if (f1.prime == f2.prime) {
				result.add(f1.prime, Math.min(f1.multiplicity, f2.multiplicity));
			}
			iter1 = this.iterator();
		}
		return result;
	}


	/**
	 * 
	 * @param pf1
	 * @param pf2
	 * @return prime factorization of the gcd of two numbers represented by pf1 and pf2
	 * @throws IllegalArguemntException if pf1 == null or pf2 == null
	 */
	public static PrimeFactorization gcd(PrimeFactorization pf1, PrimeFactorization pf2) throws IllegalArgumentException {
		if (pf1 == null || pf2 == null) {
			throw new IllegalArgumentException();
		}
		PrimeFactorizationIterator iter1 = pf1.iterator();
		PrimeFactorizationIterator iter2 = pf2.iterator();
		PrimeFactorization result = new PrimeFactorization();

		while(iter2.hasNext()){
			PrimeFactor f1 = iter1.next();
			PrimeFactor f2 = iter2.next();
			while (f1.prime != f2.prime && iter1.hasNext()) {
				f1 = iter1.next();
			}
			if (f1.prime == f2.prime) {
				result.add(f1.prime, Math.min(f1.multiplicity, f2.multiplicity));
			}
			iter1 = pf1.iterator();
		}
		return result; 
	}


	/**
	 * Computes the least common multiple (lcm) of the two integers represented by this object 
	 * and pf.  The list-based algorithm is given in Section 4.3 in the project description. 
	 * 
	 * @param pf  
	 * @return factored least common multiple  
	 * @throws IllegalArguemntException if pf == null
	 */
	public PrimeFactorization lcm(PrimeFactorization pf) throws IllegalArgumentException{
		if (pf == null) {
			throw new IllegalArgumentException();
		}
		PrimeFactorizationIterator iter1 = iterator();
		PrimeFactorizationIterator iter2 = pf.iterator();
		PrimeFactorization result = new PrimeFactorization();
		PrimeFactor f1 = new PrimeFactor(iter1.cursor.pFactor.prime,iter1.cursor.pFactor.multiplicity);
		PrimeFactor f2 = new PrimeFactor(iter2.cursor.pFactor.prime,iter2.cursor.pFactor.multiplicity);

		while(iter1.hasNext() && iter2.hasNext()){


			if (f1.prime != f2.prime) {
				if (f1.prime < f2.prime) {
					result.add(f1.prime, f1.multiplicity);
					f1 = iter1.next();
				}
				else {
					result.add(f2.prime, f2.multiplicity);
					f2 = iter2.next();
				}
			}
			else {
				int temp = Math.max(f1.multiplicity, f2.multiplicity);
				Node node = new Node(f1.prime, temp);
				result.add(node.pFactor.prime, node.pFactor.multiplicity);
				f1 = iter1.next();
				f2 = iter2.next();
			}
		}
		if (iter1.hasNext()) {
			while (iter1.hasNext()) {
				result.add(f1.prime, f1.multiplicity);
				f1 = iter1.next();
			}
		}
		else {
			while (iter2.hasNext()) {
				result.add(f2.prime, f2.multiplicity);
				f2 = iter2.next();
			}
		}
		result.updateValue();
		return result;

	}


	/**
	 * Computes the least common multiple of the represented integer v and an integer n. Construct a 
	 * PrimeFactors object using n and then call the lcm() method above.  Calls the first lcm() method. 
	 * 
	 * @param n
	 * @return factored least common multiple 
	 * @throws IllegalArgumentException if n < 1
	 */
	public PrimeFactorization lcm(long n) throws IllegalArgumentException {
		if (n < 1){
			throw new IllegalArgumentException();
		}
		PrimeFactorization p1 = new PrimeFactorization(n);
		PrimeFactorization p2 = this.lcm(p1);
		return p2;
	}

	/**
	 * Computes the least common multiple of the integers represented by pf1 and pf2. 
	 * 
	 * @param pf1
	 * @param pf2
	 * @return prime factorization of the lcm of two numbers represented by pf1 and pf2
	 * @throws IllegalArguemntException if pf1 == null or pf2 == null
	 */
	public static PrimeFactorization lcm(PrimeFactorization pf1, PrimeFactorization pf2) throws IllegalArgumentException
	{
		if (pf1 == null || pf2 == null) {
			throw new IllegalArgumentException();
		}
		pf1.lcm(pf2);
		PrimeFactorization result = new PrimeFactorization(pf1);
		return result;
	}


	// ------------
	// List Methods
	// ------------

	/**
	 * Traverses the list to determine if p is a prime factor. 
	 * 
	 * Precondition: p is a prime. 
	 * 
	 * @param p  
	 * @return true  if p is a prime factor of the number v represented by this linked list
	 *         false otherwise 
	 * @throws IllegalArgumentException if p is not a prime
	 */
	public boolean containsPrimeFactor(int p) throws IllegalArgumentException
	{
		if (!isPrime(p)){
			throw new IllegalArgumentException();
		}
		PrimeFactorizationIterator iter = iterator();
		while (iter.hasNext()){
			PrimeFactor n = iter.next();
			if (n.prime == p){
				return true;
			}
		}
		return false;
	}

	// The next two methods ought to be private but are made public for testing purpose. Keep
	// them public 

	/**
	 * Adds a prime factor p of multiplicity m.  Search for p in the linked list.  If p is found at 
	 * a node N, add m to N.multiplicity.  Otherwise, create a new node to store p and m. 
	 *  
	 * Precondition: p is a prime. 
	 * 
	 * @param p  prime 
	 * @param m  multiplicity
	 * @return   true  if m >= 1
	 *           false if m < 1   
	 */
	public boolean add(int p, int m) 
	{
		if (m < 1){
			return false;
		}
		PrimeFactorizationIterator iter = iterator();
		while (iter.hasNext()) {
			PrimeFactor f = iter.next();
			if (f.prime > p) {
				iter.previous();
				if (iter.cursor.previous.pFactor == null) {
					iter.cursor.previous = this.head;
					this.link(iter.cursor, new Node(p, m));
					size++;
					updateValue();
					return true;
				}
				iter.add(new PrimeFactor(p, m));
				return true;
			}

			else if (f.prime == p) {
				f.multiplicity += m;
				updateValue();
				return true;
			}
		}
		link(iter.cursor, new Node(p, m));
		size++;
		updateValue();
		return true;
	}


	/**
	 * Removes m from the multiplicity of a prime p on the linked list.  It starts by searching 
	 * for p.  Returns false if p is not found, and true if p is found. In the latter case, let 
	 * N be the node that stores p. If N.multiplicity > m, subtracts m from N.multiplicity.  
	 * If N.multiplicity <= m, removes the node N.  
	 * 
	 * Precondition: p is a prime. 
	 * 
	 * @param p
	 * @param m
	 * @return true  when p is found. 
	 *         false when p is not found. 
	 * @throws IllegalArgumentException if m < 1
	 */
	public boolean remove(int p, int m) throws IllegalArgumentException
	{
		if (m < 1){
			throw new IllegalArgumentException();
		}
		PrimeFactorizationIterator iter = iterator();
		while(iter.hasNext()){
			PrimeFactor n = iter.next();
			if (n.prime != p){
				continue;
			}
			else if (n.multiplicity > m){
				n.multiplicity -= m;
				break;
			}
			else{
				iter.remove();
				return false;
			}
		}
		return true;
	}


	/**
	 * 
	 * @return size of the list
	 */
	public int size() 
	{
		return size; 
	}


	/**
	 * Writes out the list as a factorization in the form of a product. Represents exponentiation 
	 * by a caret.  For example, if the number is 5814, the returned string would be printed out 
	 * as "2 * 3^2 * 17 * 19". 
	 */
	@Override 
	public String toString()
	{
		String result = "";
		if (value == 1) {
			result += 1;
			return result;
		}
		PrimeFactorizationIterator p = iterator();
		result += p.next().toString();
		while(p.hasNext()){
			result += " * " + p.next().toString();
		}
		return result;
	}


	// The next three methods are for testing, but you may use them as you like.  

	/**
	 * @return true if this PrimeFactorization is representing a value that is too large to be within 
	 *              long's range. e.g. 999^999. false otherwise.
	 */
	public boolean valueOverflow() {
		return value == OVERFLOW;
	}

	/**
	 * @return value represented by this PrimeFactorization, or -1 if valueOverflow()
	 */
	public long value() {
		return value;
	}


	public PrimeFactor[] toArray() {
		PrimeFactor[] arr = new PrimeFactor[size];
		int i = 0;
		for (PrimeFactor pf : this)
			arr[i++] = pf;
		return arr;
	}



	@Override
	public PrimeFactorizationIterator iterator() {
		return new PrimeFactorizationIterator();
	}

	/**
	 * Doubly-linked node type for this class.
	 */
	private class Node {
		public PrimeFactor pFactor;			// prime factor 
		public Node next;
		public Node previous;

		/**
		 * Default constructor for creating a dummy node.
		 */
		public Node(){
			pFactor = null;
			next = null;
			previous = null;
		}

		/**
		 * Precondition: p is a prime
		 * 
		 * @param p	 prime number 
		 * @param m  multiplicity 
		 * @throws IllegalArgumentException if m < 1 
		 */
		public Node(int p, int m) throws IllegalArgumentException {	
			if (m < 1) {
				throw new IllegalArgumentException();
			}
			pFactor = new PrimeFactor(p, m);
			next = null;
			previous = null;
		}   


		/**
		 * Constructs a node over a provided PrimeFactor object. 
		 * 
		 * @param pf
		 * @throws IllegalArgumentException
		 */
		public Node(PrimeFactor pf) {
			pFactor = new PrimeFactor(pf.prime, pf.multiplicity);
			next = null;
			previous = null;
		}


		/**
		 * Printed out in the form: prime + "^" + multiplicity.  For instance "2^3". 
		 * Also, deal with the case pFactor == null in which a string "dummy" is 
		 * returned instead.  
		 */
		@Override
		public String toString() {
			return (Integer.toString(pFactor.prime) + "^" + Integer.toString(pFactor.multiplicity));
		}
	}


	private class PrimeFactorizationIterator implements ListIterator<PrimeFactor>{  	
		// Class invariants: 
		// 1) logical cursor position is always between cursor.previous and cursor
		// 2) after a call to next(), cursor.previous refers to the node just returned 
		// 3) after a call to previous() cursor refers to the node just returned 
		// 4) index is always the logical index of node pointed to by cursor

		private Node cursor = head.next;
		private Node pending = null;    // node pending for removal
		private int index = 0;      

		// other instance variables ... 


		/**
		 * Default constructor positions the cursor before the smallest prime factor.
		 */
		public PrimeFactorizationIterator(){
			cursor = head.next;
			pending = null;
			index = 0;
		}

		@Override
		public boolean hasNext(){
			if (index < (size)) {
				return true;
			}
			return false; 
		}


		@Override
		public boolean hasPrevious(){
			if (index > 0) {
				return true;
			}
			return false; 
		}


		@Override 
		public PrimeFactor next() {
			if (hasNext()) {
				pending = cursor;
				cursor = cursor.next;
				index ++;
				return pending.pFactor;
			}
			return null; 
		}


		@Override 
		public PrimeFactor previous() {
			if (hasPrevious()) {
				pending = cursor;
				cursor = cursor.previous;
				index --;
				return pending.pFactor;
			}
			return null; 
		}


		/**
		 *  Removes the prime factor returned by next() or previous()
		 *  
		 *  @throws IllegalStateException if pending == null 
		 */
		@Override
		public void remove() throws IllegalStateException{
			if (pending == null) {
				throw new IllegalStateException();
			}
			unlink(pending);
			size --;
		}


		/**
		 * Adds a prime factor at the cursor position.  The cursor is at a wrong position 
		 * in either of the two situations below: 
		 * 
		 *    a) pf.prime < cursor.previous.pFactor.prime if cursor.previous != head. 
		 *    b) pf.prime > cursor.pFactor.prime if cursor != tail. 
		 * 
		 * Take into account the possibility that pf.prime == cursor.pFactor.prime. 
		 * 
		 * Precondition: pf.prime is a prime. 
		 * 
		 * @param pf  
		 * @throws IllegalArgumentException if the cursor is at a wrong position. 
		 */
		@Override
		public void add(PrimeFactor pf) throws IllegalArgumentException {
			if ((cursor.previous != head && pf.prime < cursor.previous.pFactor.prime)		//(a)
					|| (cursor != tail && pf.prime > cursor.pFactor.prime)) {				//(b)
				throw new IllegalArgumentException();
			}
			Node n = new Node(pf.clone());
			link (cursor.previous, n);
			size ++;
		}


		@Override
		public int nextIndex() 
		{
			return index;
		}


		@Override
		public int previousIndex() 
		{
			return index - 1;
		}

		@Deprecated
		@Override
		public void set(PrimeFactor pf) 
		{
			throw new UnsupportedOperationException(getClass().getSimpleName() + " does not support set method");
		}

		// Other methods you may want to add or override that could possibly facilitate 
		// other operations, for instance, addition, access to the previous element, etc.
		// 
		// ...
		// 
	}


	// --------------
	// Helper methods 
	// -------------- 

	/**
	 * Inserts toAdd into the list after current without updating size.
	 * 
	 * Precondition: current != null, toAdd != null
	 */
	private void link(Node current, Node toAdd){
		toAdd.previous = current.previous;
		toAdd.next = current;
		current.previous.next = toAdd;
		current.previous = toAdd;
	}


	/**
	 * Removes toRemove from the list without updating size.
	 */
	private void unlink(Node toRemove){
		toRemove.previous.next = toRemove.next;
		toRemove.next.previous = toRemove.previous;
	}


	/**
	 * Remove all the nodes in the linked list except the two dummy nodes. 
	 * 
	 * Made public for testing purpose.  Ought to be private otherwise. 
	 */
	public void clearList() { 
		new PrimeFactorization();
	}	

	/**
	 * Multiply the prime factors (with multiplicities) out to obtain the represented integer.  
	 * Use Math.multiply(). If an exception is throw, assign OVERFLOW to the instance variable value.  
	 * Otherwise, assign the multiplication result to the variable. 
	 * 
	 */
	private void updateValue() {
		PrimeFactorizationIterator pfi = iterator();
		int temp = 1;
		try {		
			while (pfi.hasNext()) {
				if (pfi.cursor.pFactor.multiplicity > 1) {
					for (int i = 0; i < pfi.cursor.pFactor.multiplicity; i ++) {
						temp = Math.multiplyExact(temp, pfi.cursor.pFactor.prime);
					}
				}
				else {
					temp = Math.multiplyExact(temp, pfi.cursor.pFactor.prime);
					pfi.next();
				}
			}
			this.value = temp;
		} 

		catch (ArithmeticException e) {
			value = OVERFLOW;
		}

	}

	//	public static void main(String[] args) {
	//		PrimeFactor pf = new PrimeFactor (1, 1);
	//		int a = pf.prime;
	//		String b = pf.toString();
	//		
	//	}
}
