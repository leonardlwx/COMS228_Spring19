package edu.iastate.cs228.hw5;


import java.io.FileNotFoundException;
import java.util.Scanner; 

/**
 *  
 * @author Wei Xian Lim
 *
 */

/**
 * 
 * The Transactions class simulates video transactions at a video store. 
 *
 */
public class Transactions 
{

	/**
	 * The main method generates a simulation of rental and return activities.  
	 *  
	 * @param args
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException {	
		// 
		// 1. Construct a VideoStore object.
		// 2. Simulate transactions as in the example given in Section 4 of the 
		//    the project description. 
		Scanner s = new Scanner (System.in);
		VideoStore vs = new VideoStore("videoList1.txt");

		System.out.println("Transactions at a Video Store");
		System.out.println("keys: 1 (rent)      2 (bulk rent)");
		System.out.println("      3 (return)    4 (bulk return)");
		System.out.println("      5 (summary)   6 (exit)");
		System.out.println("");
		System.out.println("Transaction: ");
		int input = s.nextInt();

		while (input != 6) {
			if (input == 1) {
				System.out.println("Film to rent: ");
				s.nextLine();
				String filmInput = s.nextLine();
				Video vd = new Video(VideoStore.parseFilmName(filmInput), VideoStore.parseNumCopies(filmInput));
				try {
					vs.videoRent(vd.getFilm(), vd.getNumCopies());
				}
				catch (IllegalArgumentException | FilmNotInInventoryException | AllCopiesRentedOutException e) {
					System.out.println(e.getMessage());
				}
			}
			else if (input == 2) {
				System.out.println("Video file (rent): ");
				String filmInput = s.next();
				try {
					vs.bulkRent(filmInput);
				}
				catch (IllegalArgumentException | FilmNotInInventoryException | AllCopiesRentedOutException e) {
					System.out.println(e.getMessage());
				}
			}
			else if (input == 3) {
				System.out.println("Film to return: ");
				s.nextLine();
				String filmInput = s.nextLine();
				Video vd = new Video(VideoStore.parseFilmName(filmInput), VideoStore.parseNumCopies(filmInput));
				try {
					vs.videoReturn(vd.getFilm(), vd.getNumCopies());
				}
				catch (IllegalArgumentException | FilmNotInInventoryException e) {
					System.out.println(e.getMessage());
				}
			}
			else if (input == 4) {
				System.out.println("Video file (return): ");
				String filmInput = s.next();
				try {
					vs.bulkReturn(filmInput);
				}
				catch (IllegalArgumentException | FilmNotInInventoryException e) {
					System.out.println(e.getMessage());
				}
			}
			else { // 5
				System.out.println("");
				System.out.println(vs.transactionsSummary());
			}
			System.out.println("");
			System.out.println("Transaction: ");
			input = s.nextInt();
		}
		s.close();
	}
}
