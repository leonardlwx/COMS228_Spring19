package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;

/**
 *  
 * @author Wei Xian Lim
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	// Other private instance variables if you need ... 
	
	/** 
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		super(pts);
		
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 */
	@Override 
	public void sort()
	{
		mergeSortRec(points);
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts)
	{
		points = mergeSort(pts);
	}

	
	// Other private methods in case you need ...
	private Point[] mergeSort(Point[] pts) {
		if(pts.length <= 1)
			return pts;
				
		Point[] a = new Point[pts.length/2];
		Point[] b = new Point[pts.length - pts.length/2];
		
		int i;
		for(i = 0; i < a.length; i++) {
			a[i] = pts[i];
		}
		int j = pts.length/2;
		for(i = 0; i < b.length && j < pts.length; i++, j++) {
			b[i] = pts[j];
		}
		
		/* deal with our split arrays */
		
		Point[] c = mergeSort(a);
		Point[] d = mergeSort(b);
		int p = c.length;
		int q = d.length;
		
		Point[] e = new Point[p+q];
		
		//System.out.println("E length: " + e.length);
		
		int k = 0;
		i = 0;
		j = 0;
		while(i < p && j < q) {
			if(pointComparator.compare(c[i], d[j]) <= 0) {
				e[k] = c[i];
				i++;
				k++;
			} else {
				e[k] = d[j];
				j++;
				k++;
			}
		}
		if(i >= p) {
			for(; j < q; j++) {
				e[k] = d[j];
				k++;
			}
		} else {
			for(; i < p; i++) {
				e[k] = c[i];
				k++;
			}
		}
		
		
		return e;
	}
}
