package edu.iastate.cs228.hw4;

import java.io.File;


/**
 *  
 * @author Wei Xian Lim
 *
 */

/**
 * 
 * This class evaluates input infix and postfix expressions. 
 *
 */

import java.util.HashMap;
import java.util.Scanner;

public class InfixPostfix 
{

	/**
	 * Repeatedly evaluates input infix and postfix expressions.  See the project description
	 * for the input description. It constructs a HashMap object for each expression and passes it 
	 * to the created InfixExpression or PostfixExpression object. 
	 *  
	 * @param args
	 **/
	public static void main(String[] args) throws Exception {
		System.out.println("Evaluation of Infix and Postfix Expressions");
		System.out.println("keys: 1 (standard input)  2 (file input)  3 (exit)");
		System.out.println("(Enter �I� before an infix expression, �P� before a postfix expression�)");
		Scanner scanIn = new Scanner(System.in);
		int num = 1;
		System.out.print("Trial" + " "+ num +":");
		int key = scanIn.nextInt();
		while(key == 1 || key == 2 || key == 3) {

			if(key == 1) {
				System.out.print("Expression:");
				String input = "" + scanIn.next();

				if(input.charAt(0) == 'I') { 
					String infix = scanIn.nextLine();

					if(containsVariable(infix)) { 
						HashMap<Character, Integer> hMap = new HashMap<Character, Integer>();
						Expression exp = new InfixExpression(infix, hMap);
						System.out.println("Infix form: " + exp.toString());
						((InfixExpression)exp).postfix();
						System.out.println("Postfix form: " + exp.postfixExpression);
						System.out.println("where");
						for(int i = 0; i < infix.length(); i ++) {
							if(!exp.varTable.containsKey((infix.charAt(i))) && Character.isLowerCase(infix.charAt(i))) {
								System.out.print(infix.charAt(i) + " = ");
								exp.varTable.put(infix.charAt(i), scanIn.nextInt());
							}
						}
						System.out.println("Expression Value: " + exp.evaluate());
					}
					else { 
						InfixExpression temp = new InfixExpression(infix);
						System.out.println("Infix form: " + temp.toString());
						temp.postfix();
						System.out.println("Postfix form: " + temp.postfixString());
						System.out.println("Expression value: " + temp.evaluate());
					}
				}
				else if(input.charAt(0) == 'P') { 
					String post = scanIn.nextLine();
					HashMap<Character, Integer> hMap = new HashMap<Character, Integer>();
					PostfixExpression temp;
					if(containsVariable(post)) {
						temp = new PostfixExpression(post, hMap);
						System.out.println("Postfix form: " + temp.postfixExpression);
						System.out.println("where");
						for(int i = 0; i < post.length(); i ++) {
							if(Character.isLowerCase(post.charAt(i))){
								System.out.print(post.charAt(i) + " = ");
								int val = scanIn.nextInt();
								temp.varTable.put(post.charAt(i), val);
							}
						}
						System.out.println("Expression value: " + temp.evaluate());
					}
					else { //does not contain variables
						temp = new PostfixExpression(post);
						System.out.println("Postfix form: " + temp.toString());
						System.out.println("Expression value: " + temp.evaluate());
					}
				}
			}

			if(key == 2) {
				System.out.println("Input from a file");
				System.out.print("Enter file name: " );
				String fName = scanIn.next();
				File file = new File(fName);
				Scanner fScan=new Scanner(file);
				char input = fScan.next().charAt(0);
				while(fScan.hasNext()) {
					System.out.println();

					//infix
					if(input == 'I') {
						String str = fScan.nextLine();
						if(containsVariable(str)) {
							HashMap<Character, Integer> hMap = new HashMap<Character, Integer>();
							Expression exp = new InfixExpression(str, hMap);
							System.out.println("Infix form: " + exp.toString());
							((InfixExpression)exp).postfix();
							System.out.println("Postfix form: " + exp.postfixExpression);
							System.out.println("where");
							for(int i = 0; i < distinctVariable(str); i ++) {
								char var = fScan.next().charAt(0);
								fScan.next();
								int value = fScan.nextInt();
								hMap.put(var, value);
								System.out.println(var + " = " + hMap.get(var));

								if(fScan.hasNextLine()) {
									fScan.nextLine();
								}
							}
							System.out.println("Expression value: " + exp.evaluate());
						}
						else {
							Expression exp = new InfixExpression(str);
							System.out.println("Infix form: " + exp.toString());
							((InfixExpression)exp).postfix();
							System.out.println("Postfix form: " + exp.postfixExpression);
							System.out.println("Expression value: " + exp.evaluate());
						}
					}
					else if(input == 'P') {
						String post=fScan.nextLine();
						if(containsVariable(post)) {
							HashMap<Character, Integer> hMap=new HashMap<Character, Integer>();
							PostfixExpression obj = new PostfixExpression(post, hMap);
							System.out.println("Postfix form: " + obj.toString());
							System.out.println("where");
							for(int i = 0; i < distinctVariable(post); i ++) {
								char var = fScan.next().charAt(0);
								fScan.next();
								int value=fScan.nextInt();
								hMap.put(var, value);
								System.out.println(var + " = " + hMap.get(var));

								if(fScan.hasNextLine()) {
									fScan.nextLine();
								}
							}
							System.out.println("Expression value:" + obj.evaluate());
						}
						else {
							PostfixExpression obj = new PostfixExpression(post);
							System.out.println("Postfix form: " + obj.toString());
							System.out.println("Expression value: " + obj.evaluate());
						}
					}
					if(fScan.hasNextLine()) {
						char input2 = fScan.next().charAt(0);
						while(input2 != 'I' && input2 != 'P') {
							fScan.nextLine();
						}
						input = input2;
					}
				}
				fScan.close();

			}
			if(key == 3) {
				scanIn.close();
				break;
			}
			num ++;
			System.out.println();
			System.out.print("Trial" + " " + num + ":");
			key = scanIn.nextInt();
		}
		scanIn.close();
	}

	// helper methods if needed

	private static boolean containsVariable(String s) {
		for (int i = 0; i < s.length(); i ++) {
			if (Expression.isVariable(s.charAt(i))) {
				return true;
			}
		}
		return false;
	}

	private static int distinctVariable(String s) {
		String temp = "";
		for (int i = 0; i < s.length(); i ++) {
			if (Expression.isVariable(s.charAt(i)) && temp.indexOf(s.charAt(i)) == -1) {
				temp += s.charAt(i);
			} 

		}
		return temp.length();
	}
}