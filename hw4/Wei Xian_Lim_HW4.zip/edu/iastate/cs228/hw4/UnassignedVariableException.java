package edu.iastate.cs228.hw4;

public class UnassignedVariableException extends Exception
{
	public UnassignedVariableException()
	{
		super();
	}
	  
	public UnassignedVariableException(String msg)
	{
	    super(msg);
	}

}
